import sqlite3

def query_lineage(person_name):
    conn = sqlite3.connect('bible_ultra.db')
    cursor = conn.cursor()
    
    print(f"--- Linhagem de {person_name} ---")
    
    query = """
    WITH RECURSIVE lineage AS (
        SELECT p.id, p.name, g.parent_id, 0 as level
        FROM people p
        LEFT JOIN genealogies g ON p.id = g.person_id
        WHERE p.name = ?
        
        UNION ALL
        
        SELECT p.id, p.name, g.parent_id, l.level + 1
        FROM people p
        JOIN genealogies g ON p.id = g.person_id
        JOIN lineage l ON p.id = l.parent_id
    )
    SELECT name, level FROM lineage ORDER BY level;
    """
    
    cursor.execute(query, (person_name,))
    results = cursor.fetchall()
    
    for row in results:
        indent = "  " * row[1]
        print(f"{indent}└─ {row[0]} (Nível {row[1]})")
        
    conn.close()

if __name__ == "__main__":
    # Adicionar mais dados para o teste
    conn = sqlite3.connect('bible_ultra.db')
    c = conn.cursor()
    c.execute("INSERT INTO people (name) VALUES ('Enos')")
    enos_id = c.lastrowid
    c.execute("SELECT id FROM people WHERE name='Sete'")
    sete_id = c.fetchone()[0]
    c.execute("INSERT INTO genealogies (person_id, parent_id) VALUES (?, ?)", (enos_id, sete_id))
    conn.commit()
    conn.close()
    
    query_lineage('Enos')
