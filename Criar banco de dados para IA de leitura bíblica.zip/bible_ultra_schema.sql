-- Esquema de Banco de Dados Bíblico Ultra-Completo para IA
-- Projetado para cobrir Textos, Léxicos, Genealogias, Cronologia, Geografia e Teologia.

-- ==========================================
-- 1. ESTRUTURA TEXTUAL E TRADUÇÕES
-- ==========================================

CREATE TABLE translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    abbreviation TEXT NOT NULL UNIQUE,
    language TEXT NOT NULL,
    publication_year INTEGER,
    copyright_info TEXT
);

CREATE TABLE books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name_pt TEXT NOT NULL,
    name_en TEXT,
    name_original TEXT, -- Hebraico/Grego
    testament TEXT CHECK(testament IN ('Velho', 'Novo')),
    genre TEXT, -- Pentateuco, Profetas, Evangelhos, etc.
    author_id INTEGER, -- Referência à tabela de pessoas
    order_index INTEGER UNIQUE,
    summary TEXT
);

CREATE TABLE chapters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    number INTEGER NOT NULL,
    title TEXT, -- Alguns salmos ou capítulos têm títulos
    FOREIGN KEY (book_id) REFERENCES books(id)
);

CREATE TABLE verses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL,
    number INTEGER NOT NULL,
    text TEXT NOT NULL,
    translation_id INTEGER NOT NULL,
    reference_code TEXT, -- Ex: "JHN.3.16"
    FOREIGN KEY (chapter_id) REFERENCES chapters(id),
    FOREIGN KEY (translation_id) REFERENCES translations(id)
);

-- ==========================================
-- 2. LÉXICOS E ESTUDO DE PALAVRAS (STRONG'S)
-- ==========================================

CREATE TABLE lexicons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strong_number TEXT UNIQUE, -- Ex: G3056 (Logos)
    language TEXT CHECK(language IN ('Hebraico', 'Grego', 'Aramaico')),
    word_original TEXT NOT NULL,
    transliteration TEXT,
    pronunciation TEXT,
    definition_short TEXT,
    definition_full TEXT,
    grammar_info TEXT
);

-- Mapeamento de cada palavra do versículo ao seu número Strong
CREATE TABLE verse_word_analysis (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    verse_id INTEGER NOT NULL,
    word_index INTEGER, -- Posição da palavra no versículo
    word_text TEXT,
    strong_id INTEGER,
    morphology_code TEXT, -- Informação gramatical detalhada
    FOREIGN KEY (verse_id) REFERENCES verses(id),
    FOREIGN KEY (strong_id) REFERENCES lexicons(id)
);

-- ==========================================
-- 3. PESSOAS, GENEALOGIAS E LUGARES
-- ==========================================

CREATE TABLE people (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    meaning TEXT, -- Significado do nome
    gender TEXT,
    description TEXT,
    is_historical BOOLEAN DEFAULT TRUE
);

CREATE TABLE genealogies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id INTEGER NOT NULL,
    parent_id INTEGER, -- Pai ou Mãe
    relationship_type TEXT DEFAULT 'Filho(a)',
    FOREIGN KEY (person_id) REFERENCES people(id),
    FOREIGN KEY (parent_id) REFERENCES people(id)
);

CREATE TABLE locations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    modern_name TEXT,
    region TEXT,
    latitude REAL,
    longitude REAL,
    description TEXT
);

-- ==========================================
-- 4. EVENTOS E CRONOLOGIA
-- ==========================================

CREATE TABLE events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    start_year INTEGER, -- Anos negativos para AC
    end_year INTEGER,
    location_id INTEGER,
    FOREIGN KEY (location_id) REFERENCES locations(id)
);

CREATE TABLE event_verses (
    event_id INTEGER NOT NULL,
    verse_id INTEGER NOT NULL,
    PRIMARY KEY (event_id, verse_id),
    FOREIGN KEY (event_id) REFERENCES events(id),
    FOREIGN KEY (verse_id) REFERENCES verses(id)
);

-- ==========================================
-- 5. RECURSOS TEOLÓGICOS E IA
-- ==========================================

CREATE TABLE topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    category TEXT, -- Ex: Doutrina, Ética, História
    description TEXT
);

CREATE TABLE verse_topics (
    verse_id INTEGER NOT NULL,
    topic_id INTEGER NOT NULL,
    relevance_score REAL,
    PRIMARY KEY (verse_id, topic_id),
    FOREIGN KEY (verse_id) REFERENCES verses(id),
    FOREIGN KEY (topic_id) REFERENCES topics(id)
);

CREATE TABLE commentaries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    author_name TEXT,
    work_title TEXT,
    verse_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    theological_bias TEXT, -- Ex: Reformado, Católico, Arminianista
    FOREIGN KEY (verse_id) REFERENCES verses(id)
);

CREATE TABLE cross_references (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_verse_id INTEGER NOT NULL,
    target_verse_id INTEGER NOT NULL,
    strength REAL, -- Quão forte é a conexão
    note TEXT,
    FOREIGN KEY (source_verse_id) REFERENCES verses(id),
    FOREIGN KEY (target_verse_id) REFERENCES verses(id)
);

-- Pesos e Medidas
CREATE TABLE weights_measures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    biblical_name TEXT NOT NULL,
    type TEXT, -- Peso, Comprimento, Volume, Moeda
    metric_value REAL, -- Valor convertido para sistema métrico
    metric_unit TEXT, -- kg, m, l, etc.
    description TEXT
);

-- ==========================================
-- 6. DADOS DO USUÁRIO E INTERAÇÃO IA
-- ==========================================

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    verse_id INTEGER,
    type TEXT, -- 'Nota', 'Destaque', 'Favorito'
    content TEXT,
    color_code TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (verse_id) REFERENCES verses(id)
);

CREATE TABLE ai_conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    session_token TEXT,
    summary TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE ai_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    role TEXT CHECK(role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    tokens_used INTEGER,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id)
);

-- Índices para otimização de busca
CREATE INDEX idx_verse_ref ON verses(reference_code);
CREATE INDEX idx_lexicon_strong ON lexicons(strong_number);
CREATE INDEX idx_people_name ON people(name);
CREATE INDEX idx_event_year ON events(start_year);
