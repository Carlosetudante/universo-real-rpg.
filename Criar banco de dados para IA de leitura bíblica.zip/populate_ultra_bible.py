import sqlite3
import os

def populate_ultra():
    db_path = 'bible_ultra.db'
    schema_path = 'bible_ultra_schema.sql'
    
    if os.path.exists(db_path):
        os.remove(db_path)
        
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    with open(schema_path, 'r') as f:
        cursor.executescript(f.read())
    
    # 1. Traduções
    cursor.execute("INSERT INTO translations (name, abbreviation, language) VALUES (?, ?, ?)", 
                   ('Almeida Revista e Corrigida', 'ARC', 'pt-BR'))
    arc_id = cursor.lastrowid
    
    # 2. Livros e Capítulos
    cursor.execute("INSERT INTO books (name_pt, testament, genre, order_index) VALUES (?, ?, ?, ?)",
                   ('Gênesis', 'Velho', 'Pentateuco', 1))
    gen_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO chapters (book_id, number) VALUES (?, ?)", (gen_id, 1))
    gen_ch1_id = cursor.lastrowid
    
    # 3. Versículos
    cursor.execute("INSERT INTO verses (chapter_id, number, text, translation_id, reference_code) VALUES (?, ?, ?, ?, ?)",
                   (gen_ch1_id, 1, 'No princípio criou Deus o céu e a terra.', arc_id, 'GEN.1.1'))
    v1_id = cursor.lastrowid
    
    # 4. Léxico (Strong's)
    cursor.execute("INSERT INTO lexicons (strong_number, language, word_original, transliteration, definition_short) VALUES (?, ?, ?, ?, ?)",
                   ('H7225', 'Hebraico', 'רֵאשִׁית', 'reshith', 'princípio, começo, primícias'))
    strong_h7225 = cursor.lastrowid
    
    # 5. Análise de Palavras
    cursor.execute("INSERT INTO verse_word_analysis (verse_id, word_text, strong_id) VALUES (?, ?, ?)",
                   (v1_id, 'princípio', strong_h7225))
    
    # 6. Pessoas e Genealogia
    cursor.execute("INSERT INTO people (name, meaning, gender, description) VALUES (?, ?, ?, ?)",
                   ('Adão', 'Homem, terra vermelha', 'Masculino', 'O primeiro homem criado por Deus.'))
    adao_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO people (name, gender) VALUES (?, ?)", ('Sete', 'Masculino'))
    sete_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO genealogies (person_id, parent_id) VALUES (?, ?)", (sete_id, adao_id))
    
    # 7. Lugares e Eventos
    cursor.execute("INSERT INTO locations (name, region, description) VALUES (?, ?, ?)",
                   ('Jardim do Éden', 'Desconhecida', 'Lugar da criação da humanidade.'))
    eden_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO events (title, start_year, location_id) VALUES (?, ?, ?)",
                   ('Criação', -4004, eden_id))
    
    # 8. Pesos e Medidas
    cursor.execute("INSERT INTO weights_measures (biblical_name, type, metric_value, metric_unit) VALUES (?, ?, ?, ?)",
                   ('Côvado', 'Comprimento', 0.45, 'm'))
    
    # 9. Tópicos e Comentários
    cursor.execute("INSERT INTO topics (name, category) VALUES (?, ?)", ('Soberania de Deus', 'Doutrina'))
    topic_id = cursor.lastrowid
    cursor.execute("INSERT INTO verse_topics (verse_id, topic_id, relevance_score) VALUES (?, ?, ?)", (v1_id, topic_id, 1.0))
    
    cursor.execute("INSERT INTO commentaries (author_name, work_title, verse_id, content) VALUES (?, ?, ?, ?)",
                   ('Matthew Henry', 'Comentário Bíblico Completo', v1_id, 'O primeiro versículo da Bíblia nos apresenta o Criador e Sua obra.'))
    
    conn.commit()
    conn.close()
    print("Banco de dados ultra-completo populado com sucesso!")

if __name__ == "__main__":
    populate_ultra()
