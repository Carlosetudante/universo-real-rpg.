import sqlite3
import os

def populate_db():
    db_path = 'bible_ai.db'
    schema_path = 'bible_ai_schema.sql'
    
    # Remover banco se já existir para começar do zero
    if os.path.exists(db_path):
        os.remove(db_path)
        
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Ler e executar o esquema
    with open(schema_path, 'r') as f:
        cursor.executescript(f.read())
    
    # 1. Inserir Traduções
    cursor.execute("INSERT INTO translations (name, abbreviation, language) VALUES (?, ?, ?)", 
                   ('Nova Versão Internacional', 'NVI', 'pt-BR'))
    nvi_id = cursor.lastrowid
    
    # 2. Inserir Livros
    cursor.execute("INSERT INTO books (name, testament, genre, order_index) VALUES (?, ?, ?, ?)",
                   ('Gênesis', 'Velho', 'Pentateuco', 1))
    genesis_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO books (name, testament, genre, order_index) VALUES (?, ?, ?, ?)",
                   ('João', 'Novo', 'Evangelhos', 43))
    john_id = cursor.lastrowid
    
    # 3. Inserir Capítulos
    cursor.execute("INSERT INTO chapters (book_id, number) VALUES (?, ?)", (genesis_id, 1))
    gen_ch1_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO chapters (book_id, number) VALUES (?, ?)", (john_id, 3))
    john_ch3_id = cursor.lastrowid
    
    # 4. Inserir Versículos
    verses = [
        (gen_ch1_id, 1, 'No princípio criou Deus o céu e a terra.', nvi_id, 'Gênesis 1:1'),
        (john_ch3_id, 16, 'Porque Deus amou o mundo de tal maneira que deu o seu Filho unigênito, para que todo aquele que nele crê não pereça, mas tenha a vida eterna.', nvi_id, 'João 3:16')
    ]
    cursor.executemany("INSERT INTO verses (chapter_id, number, text, translation_id, reference) VALUES (?, ?, ?, ?, ?)", verses)
    
    # 5. Inserir Tópicos
    cursor.execute("INSERT INTO topics (name, description) VALUES (?, ?)", ('Criação', 'Relatos sobre o início de todas as coisas.'))
    cursor.execute("INSERT INTO topics (name, description) VALUES (?, ?)", ('Amor de Deus', 'Passagens que falam sobre o amor sacrificial de Deus.'))
    
    # 6. Inserir Usuário e Nota
    cursor.execute("INSERT INTO users (username, email) VALUES (?, ?)", ('leitor_exemplo', 'contato@exemplo.com'))
    user_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO user_notes (user_id, verse_id, content) VALUES (?, ?, ?)", 
                   (user_id, 2, 'Este é o versículo mais conhecido da Bíblia.'))
    
    # 7. Inserir Sessão de Chat IA
    cursor.execute("INSERT INTO ai_chat_sessions (user_id, title) VALUES (?, ?)", (user_id, 'Dúvida sobre João 3:16'))
    session_id = cursor.lastrowid
    
    cursor.execute("INSERT INTO ai_messages (session_id, role, content) VALUES (?, ?, ?)", 
                   (session_id, 'user', 'O que significa "Filho unigênito" em João 3:16?'))
    cursor.execute("INSERT INTO ai_messages (session_id, role, content) VALUES (?, ?, ?)", 
                   (session_id, 'assistant', 'O termo "unigênito" (do grego monogenēs) significa "único em seu gênero" ou "único da espécie". No contexto de João 3:16, enfatiza a relação única e exclusiva entre Jesus e Deus Pai.'))
    
    conn.commit()
    conn.close()
    print(f"Banco de dados '{db_path}' criado e populado com sucesso!")

if __name__ == "__main__":
    populate_db()
