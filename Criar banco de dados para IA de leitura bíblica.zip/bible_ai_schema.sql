-- Esquema de Banco de Dados para IA de Auxílio Bíblico
-- Compatível com SQLite, PostgreSQL e MySQL

-- 1. Estrutura Principal da Bíblia
CREATE TABLE translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    abbreviation TEXT NOT NULL UNIQUE,
    language TEXT DEFAULT 'pt-BR'
);

CREATE TABLE books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    testament TEXT CHECK(testament IN ('Velho', 'Novo')),
    genre TEXT, -- Ex: Pentateuco, Evangelhos, Epístolas
    order_index INTEGER -- Ordem tradicional na Bíblia
);

CREATE TABLE chapters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    number INTEGER NOT NULL,
    FOREIGN KEY (book_id) REFERENCES books(id)
);

CREATE TABLE verses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL,
    number INTEGER NOT NULL,
    text TEXT NOT NULL,
    translation_id INTEGER NOT NULL,
    reference TEXT, -- Ex: "João 3:16"
    FOREIGN KEY (chapter_id) REFERENCES chapters(id),
    FOREIGN KEY (translation_id) REFERENCES translations(id)
);

-- 2. Recursos para IA e Busca Semântica
CREATE TABLE verse_embeddings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    verse_id INTEGER NOT NULL,
    embedding BLOB, -- Vetor para busca semântica (armazenado como binário ou JSON)
    model_name TEXT, -- Nome do modelo usado (ex: 'text-embedding-3-small')
    FOREIGN KEY (verse_id) REFERENCES verses(id)
);

CREATE TABLE topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE verse_topics (
    verse_id INTEGER NOT NULL,
    topic_id INTEGER NOT NULL,
    relevance_score REAL DEFAULT 1.0, -- Score de relevância da IA
    PRIMARY KEY (verse_id, topic_id),
    FOREIGN KEY (verse_id) REFERENCES verses(id),
    FOREIGN KEY (topic_id) REFERENCES topics(id)
);

CREATE TABLE cross_references (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    verse_id_source INTEGER NOT NULL,
    verse_id_target INTEGER NOT NULL,
    relationship_type TEXT, -- Ex: 'Citação', 'Alusão', 'Cumprimento'
    FOREIGN KEY (verse_id_source) REFERENCES verses(id),
    FOREIGN KEY (verse_id_target) REFERENCES verses(id)
);

-- 3. Dados do Usuário e Personalização
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    verse_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    is_private BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (verse_id) REFERENCES verses(id)
);

CREATE TABLE user_highlights (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    verse_id INTEGER NOT NULL,
    color_code TEXT DEFAULT '#FFFF00',
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (verse_id) REFERENCES verses(id)
);

-- 4. Histórico de Interação com a IA
CREATE TABLE ai_chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE ai_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    role TEXT CHECK(role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES ai_chat_sessions(id)
);

-- Índices para Performance
CREATE INDEX idx_verses_reference ON verses(reference);
CREATE INDEX idx_verses_chapter ON verses(chapter_id);
CREATE INDEX idx_user_notes_user ON user_notes(user_id);
CREATE INDEX idx_ai_messages_session ON ai_messages(session_id);
